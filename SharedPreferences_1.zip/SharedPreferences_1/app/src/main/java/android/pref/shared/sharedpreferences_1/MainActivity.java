package android.pref.shared.sharedpreferences_1;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText name, age;
    Button b1;
    TextView tname, tage;

    SharedPreferences.OnSharedPreferenceChangeListener listener;
    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //finding view ids
        name = (EditText) findViewById(R.id.ename);
        age = (EditText) findViewById(R.id.eage);
        b1 = (Button) findViewById(R.id.button);
       // b2 = (Button) findViewById(R.id.button2);
        tname = (TextView) findViewById(R.id.textViewname);
        tage = (TextView) findViewById(R.id.textViewage);
        //setting click listeners
        b1.setOnClickListener(this);
        //b2.setOnClickListener(this);

        preferences = this.getSharedPreferences("shared.pref.android.PREF_1", MODE_PRIVATE);
        listener = new SharedPreferences.OnSharedPreferenceChangeListener() {
            @Override
            public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String s) {
                System.out.println("found");

                showPreferences();

            }
        };

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button:
                storePreferences();
                break;
        }

    }

    //function to create shared preferences in private mode

    private void storePreferences() {

        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("name", name.getText().toString());
        editor.putString("age", age.getText().toString());
        if (editor.commit()) //if true => preferences saved successfully
        {
            Toast.makeText(MainActivity.this, "Preferences saved", Toast.LENGTH_LONG).show();

        } else {
            Toast.makeText(MainActivity.this, "Error occurred", Toast.LENGTH_LONG).show();
        }
    }

    //function to retrieve shared preferences
    private void showPreferences() {
        tname.setText("Name : " + preferences.getString("name", "null"));
        tage.setText("Age : " + preferences.getString("age", "null"));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        preferences.unregisterOnSharedPreferenceChangeListener(listener);

    }


    @Override
    protected void onResume() {
        super.onResume();
        preferences.registerOnSharedPreferenceChangeListener(listener);

    }
}

